CREATE TABLE IF NOT EXISTS public.p2_price_guide
(
    number_beds integer NOT NULL,
    is_smoking boolean NOT NULL,
    price_per_day numeric(13, 2) NOT NULL DEFAULT 80.00,
    CONSTRAINT composite_key PRIMARY KEY (number_beds, is_smoking)
);

ALTER TABLE public.p2_price_guide
    OWNER to postgres;

COMMENT ON COLUMN public.p2_price_guide.number_beds
    IS 'number_beds basically refers to the size of the room in terms of how many people can fit in each room. Generally, larger rooms cost more.';

COMMENT ON COLUMN public.p2_price_guide.is_smoking
    IS 'Denotes whether or not smoking is allowed in the room. In this case, rooms that allow smoking cost more than rooms that don''t allow smoking because most of the rooms in the hotel do not allow smoking.';

COMMENT ON COLUMN public.p2_price_guide.price_per_day
    IS 'This is the rate that the hotel charges per day.';
    
INSERT INTO public.p2_price_guide(
	number_beds, is_smoking)
	VALUES (1, false);
	
INSERT INTO public.p2_price_guide(
	number_beds, is_smoking, price_per_day)
	VALUES (1, true, 120.00);
	
INSERT INTO public.p2_price_guide(
	number_beds, is_smoking, price_per_day)
	VALUES (2, false, 100.00);
	
INSERT INTO public.p2_price_guide(
	number_beds, is_smoking, price_per_day)
	VALUES (2, true, 150.00);
	
CREATE TABLE IF NOT EXISTS public.p2_rooms
(
    room_id integer NOT NULL GENERATED ALWAYS AS IDENTITY ( START 1 ),
    room_size integer NOT NULL DEFAULT 1,
    room_smokes boolean NOT NULL DEFAULT false,
    CONSTRAINT primary_key PRIMARY KEY (room_id),
    CONSTRAINT price_key FOREIGN KEY (room_size, room_smokes)
        REFERENCES public.p2_price_guide (number_beds, is_smoking) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.p2_rooms
    OWNER to postgres;

COMMENT ON TABLE public.p2_rooms
    IS 'The selection of rooms available.';

COMMENT ON COLUMN public.p2_rooms.room_id
    IS 'The room number and the id number of this room.';

COMMENT ON COLUMN public.p2_rooms.room_size
    IS 'How many people can fit in the room.';

COMMENT ON COLUMN public.p2_rooms.room_smokes
    IS 'Is smoking allowed in this room? True if yes. Otherwise false.';

COMMENT ON CONSTRAINT price_key ON public.p2_rooms
    IS 'The size of the room and whether smoking is allowed or not determine the overall price per night for the room.';
    
INSERT INTO public.p2_rooms(
	room_size, room_smokes)
	VALUES (1, true);
	
INSERT INTO public.p2_rooms(
	room_size, room_smokes)
	VALUES (2, true);
	
INSERT INTO public.p2_rooms(
	room_size, room_smokes)
	VALUES (1, true);
	
INSERT INTO public.p2_rooms(
	room_size, room_smokes)
	VALUES (1, false);
	
INSERT INTO public.p2_rooms(
	room_size, room_smokes)
	VALUES (2, false);
	
INSERT INTO public.p2_rooms(
	room_size, room_smokes)
	VALUES (1, false);
	
INSERT INTO public.p2_rooms(
	room_size, room_smokes)
	VALUES (2, false);
	
INSERT INTO public.p2_rooms(
	room_size, room_smokes)
	VALUES (1, false);
	
INSERT INTO public.p2_rooms(
	room_size, room_smokes)
	VALUES (2, false);
	
INSERT INTO public.p2_rooms(
	room_size, room_smokes)
	VALUES (1, false);

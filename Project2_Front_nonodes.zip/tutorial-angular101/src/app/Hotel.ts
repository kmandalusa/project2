export default class Hotel {

    customer_name: String;
    phonenumber: String;
    daysbooked: String;
    bookingstatus: String;
}
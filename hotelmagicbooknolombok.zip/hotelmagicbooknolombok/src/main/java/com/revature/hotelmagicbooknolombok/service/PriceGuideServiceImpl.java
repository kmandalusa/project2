package com.revature.hotelmagicbooknolombok.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.revature.hotelmagicbooknolombok.repo.PriceGuideRepository;
import com.revature.hotelmagicbooknolombok.service.PriceGuideService;
import com.revature.hotelmagicbooknolombok.model.PriceGuide;

import javafx.util.Pair;

/**
 * @author Dipanjali Ghosh
 *
 */
@Service
public class PriceGuideServiceImpl implements PriceGuideService {

	@Autowired
	PriceGuideRepository priceGuideRepository;
	
	@Override
	public List<PriceGuide> findAll() {
		return priceGuideRepository.findAll();
	}

	@Override
	public PriceGuide findById(Pair<Integer, Boolean> priceId) {
		return priceGuideRepository.getById(priceId);
	}

	@Override
	public void save(PriceGuide priceGuide) {
		priceGuideRepository.save(priceGuide);

	}

	@Override
	public void update(Pair<Integer, Boolean> priceId, PriceGuide priceGuide) {
		priceGuideRepository.save(priceGuide);

	}

	@Override
	public void delete(Pair<Integer, Boolean> priceId) {
		priceGuideRepository.deleteById(priceId);

	}

}

